package com.zsz.chat

import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI

class WebSocketManager(private val listener: WebSocketListener) {
    private var webSocketClient: WebSocketClient? = null

    interface WebSocketListener {
        fun onMessage(message: ChatMessage)
        fun onConnected()
        fun onDisconnected()
    }

    fun connect() {
        try {
            val uri = URI("wss://zszai.iepose.cn")
            webSocketClient = object : WebSocketClient(uri) {
                override fun onOpen(serverHandshake: ServerHandshake) {
                    // Send gateway token after connection
                    webSocketClient?.send("AA123456")
                    listener.onConnected()
                }

                override fun onMessage(message: String) {
                    listener.onMessage(ChatMessage(message, isUser = false))
                }

                override fun onClose(code: Int, reason: String?, remote: Boolean) {
                    listener.onDisconnected()
                }

                override fun onError(ex: Exception) {
                    listener.onMessage(ChatMessage("连接错误: ${ex.message}", isUser = false))
                }
            }
            webSocketClient?.connect()
        } catch (e: Exception) {
            listener.onMessage(ChatMessage("连接失败: ${e.message}", isUser = false))
        }
    }

    fun sendMessage(message: String) {
        webSocketClient?.takeIf { it.isOpen }?.send(message)
    }

    fun disconnect() {
        webSocketClient?.close()
        webSocketClient = null
    }
}