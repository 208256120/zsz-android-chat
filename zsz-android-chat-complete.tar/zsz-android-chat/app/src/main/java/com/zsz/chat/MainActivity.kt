package com.zsz.chat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.zsz.chat.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var webSocketManager: WebSocketManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupWebSocket()
        setupListeners()
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter()
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = chatAdapter
        }
    }

    private fun setupWebSocket() {
        webSocketManager = WebSocketManager(object : WebSocketManager.WebSocketListener {
            override fun onMessage(message: ChatMessage) {
                runOnUiThread {
                    chatAdapter.addMessage(message)
                    binding.recyclerView.scrollToPosition(chatAdapter.itemCount - 1)
                }
            }

            override fun onConnected() {
                runOnUiThread {
                    chatAdapter.addMessage(ChatMessage("已连接到 OpenClaw", isUser = false))
                }
            }

            override fun onDisconnected() {
                runOnUiThread {
                    chatAdapter.addMessage(ChatMessage("已断开连接", isUser = false))
                }
            }
        })
        webSocketManager.connect()
    }

    private fun setupListeners() {
        binding.sendButton.setOnClickListener {
            val messageText = binding.messageEditText.text.toString().trim()
            if (messageText.isNotEmpty()) {
                val message = ChatMessage(messageText, isUser = true)
                chatAdapter.addMessage(message)
                webSocketManager.sendMessage(messageText)
                binding.messageEditText.text.clear()
                binding.recyclerView.scrollToPosition(chatAdapter.itemCount - 1)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketManager.disconnect()
    }
}