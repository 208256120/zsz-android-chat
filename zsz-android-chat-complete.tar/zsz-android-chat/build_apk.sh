#!/bin/bash

# Simple APK build script for zsz灰度
# Run this in the zsz-android-chat directory

echo "Building zsz灰度 Android APK..."

# Make gradlew executable
chmod +x ./gradlew

# Clean and build the APK
./gradlew clean
./gradlew assembleDebug

# Check if build was successful
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "✅ APK build successful!"
    echo "APK location: app/build/outputs/apk/debug/app-debug.apk"
    echo "APK size: $(du -h "app/build/outputs/apk/debug/app-debug.apk" | cut -f1)"
else
    echo "❌ APK build failed!"
    exit 1
fi